from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user, password, host, port, db, collection):
        # Initializing Connection using passed parameters
        self.client = MongoClient(f'mongodb://{user}:{password}@{host}:{port}')
        self.database = self.client[db]
        self.collection = self.database[collection]
        
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary  
            return True # True if insertion was succesful         
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, query):
        if  query is not None:
            try:
                result_cursor = self.collection.find(query)
                result_list = list(result_cursor) # convert cursor to a list of dictionaries
                if result_list:
                    return result_list
                else:
                    return[] # Return empty when no documents match the query
            except Exception as e:
                print(f"Error querying data: {e}")
                return []
        else:
            raise ValueError("Cannot perform search, query parameter is empty.")

# Update method to implement the U in CRUD.
    def update(self, query, new_values):
        if query is not None and new_values is not None:
            result = self.collection.update_many(query, new_values)
            return result.modified_count
        else:
            raise ValueError("Cannot perform update, query or new_value parameter is empty.")
            
# Delete method to implement D in CRUD.
    def delete(self, query):
        if query is not None:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise ValueError("Cannot perform deletion, query parameter is empty")
        
